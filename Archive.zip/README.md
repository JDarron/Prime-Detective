Welcome to Prime Detective


Requirements:
- Node


Instructions
- git clone git@github.com:JDarron/Prime-Detective.git
- cd Prime-Detective
- npm install
- npm start